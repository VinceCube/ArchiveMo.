<?php
include './vendor/autoload.php';
Use Sentiment\Analyzer;
$analyzer = new Analyzer(); 

use Stichoza\GoogleTranslate\GoogleTranslate;
$tr = new GoogleTranslate('en'); // Translates into English

echo $word = "Holy Shit that was awesome!";
echo "<br/>";
//echo $nword = $tr->setSource('fil')->setTarget('en')->translate($word);
echo "<br/>";
$output_text = $analyzer->getSentiment($word);
echo "Positive ".($output_text['pos']*100)."%";
echo "<hr>";
echo "Neutral ".($output_text['neu']*100)."%";
echo "<hr>";
echo "Negative ".($output_text['neg']*100)."%";
